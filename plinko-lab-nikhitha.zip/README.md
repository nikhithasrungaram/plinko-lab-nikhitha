# Plinko Lab — plinko-lab-nikhitha

A provably-fair Plinko implementation built to the Daphnis Labs take-home spec.

## Quickstart (dev)
1. Install dependencies:
   ```bash
   npm install
   npx prisma generate
   npx prisma migrate dev --name init
   ```
2. Start dev server:
   ```bash
   npm run dev
   ```
3. Run tests:
   ```bash
   npm test
   ```

## Features
- Next.js + TypeScript (App Router)
- SQLite + Prisma
- Provably-fair commit-reveal: `commitHex = SHA256(serverSeed:nonce)`, `combinedSeed = SHA256(serverSeed:clientSeed:nonce)`
- Deterministic engine with xorshift32 PRNG seeded by first 4 bytes (big-endian) of combinedSeed.
- Matter.js powered visual with authoritative deterministic decisions.
- Verifier page at `/verify`
- Unit tests reproducing provided test vector.

## Deployment (Vercel)
1. Create a GitHub repo and push this project.
2. Connect the repo to Vercel (Import Project). Vercel detects Next.js automatically.
3. Add environment variable `DATABASE_URL="file:./dev.db"` for preview if needed.

## AI usage
I used AI to draft initial code structure and README. I reviewed and adjusted all logic (PRNG seeding, rounding) to match the spec and test vectors.

Good luck! — Nikhitha
