export class XorShift32 {
  private state: number;
  constructor(seed: number) {
    this.state = seed >>> 0;
    if (this.state === 0) this.state = 0xdeadbeef >>> 0;
  }
  nextUint32(): number {
    let x = this.state;
    x ^= (x << 13) >>> 0;
    x ^= (x >>> 17) >>> 0;
    x ^= (x << 5) >>> 0;
    this.state = x >>> 0;
    return this.state;
  }
  rand(): number {
    return this.nextUint32() / 4294967296;
  }
}
export function seedFromHexBE(hex: string): number {
  const h = hex.slice(0, 8);
  const b0 = parseInt(h.slice(0,2) || '0', 16);
  const b1 = parseInt(h.slice(2,4) || '0', 16);
  const b2 = parseInt(h.slice(4,6) || '0', 16);
  const b3 = parseInt(h.slice(6,8) || '0', 16);
  return ((b0<<24)|(b1<<16)|(b2<<8)|b3) >>> 0;
}
