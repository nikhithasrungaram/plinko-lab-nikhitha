export type Peg = { leftBias: number };
export type PegMap = Peg[][];
export const R = 12;

function sha256Hex(input: string): string {
  // lightweight SHA256 via SubtleCrypto (browser) - but for demo we don't use hash on client.
  return '';
}

// Simple xorshift32
class XorShift32 {
  state: number;
  constructor(seed:number){ this.state = seed >>> 0; if(this.state===0) this.state = 0xdeadbeef >>> 0;}
  nextUint32(){ let x=this.state; x ^= (x<<13)>>>0; x ^= (x>>>17)>>>0; x ^= (x<<5)>>>0; this.state = x>>>0; return this.state;}
  rand(){ return this.nextUint32()/4294967296; }
}
function seedFromHexBE(hex:string){
  const h = hex.slice(0,8);
  const b0 = parseInt(h.slice(0,2)||'0',16);
  const b1 = parseInt(h.slice(2,4)||'0',16);
  const b2 = parseInt(h.slice(4,6)||'0',16);
  const b3 = parseInt(h.slice(6,8)||'0',16);
  return ((b0<<24)|(b1<<16)|(b2<<8)|b3)>>>0;
}

export function computeRound(combinedSeedHex:string, dropColumn:number){
  const seed = seedFromHexBE(combinedSeedHex);
  const prng = new XorShift32(seed);
  const pegMap:PegMap = [];
  for(let r=0;r<R;r++){
    const row:Peg[] = [];
    for(let p=0;p<r+1;p++){
      const v = prng.rand();
      const leftBias = 0.5 + (v - 0.5) * 0.2;
      const rounded = Math.round(leftBias * 1e6) / 1e6;
      row.push({ leftBias: rounded });
    }
    pegMap.push(row);
  }
  let pos = 0;
  const path:('L'|'R')[] = [];
  const adj = (dropColumn - Math.floor(R/2)) * 0.01;
  for(let r=0;r<R;r++){
    const pegIndex = Math.min(pos, r);
    const peg = pegMap[r][pegIndex];
    let bias = peg.leftBias + adj;
    if (bias<0) bias=0;
    if (bias>1) bias=1;
    const rnd = prng.rand();
    if (rnd < bias) path.push('L'); else { path.push('R'); pos += 1; }
  }
  return { pegMap, path, binIndex: pos, pegMapHash: '' };
}
