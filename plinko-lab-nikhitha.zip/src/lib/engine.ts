import { sha256Hex } from './hash';
import { XorShift32, seedFromHexBE } from './prng';

export type Peg = { leftBias: number };
export type PegMap = Peg[][];

export const R = 12;
export const BINS = R + 1;

function buildPegMap(prng: XorShift32): PegMap {
  const pegMap: PegMap = [];
  for (let r = 0; r < R; r++) {
    const row: Peg[] = [];
    for (let p = 0; p < r+1; p++) {
      const v = prng.rand();
      const leftBias = 0.5 + (v - 0.5) * 0.2;
      const rounded = Math.round(leftBias * 1e6) / 1e6;
      row.push({ leftBias: rounded });
    }
    pegMap.push(row);
  }
  return pegMap;
}

function pegMapHashOf(pegMap: PegMap): string {
  const norm = pegMap.map(row => row.map(peg => ({ leftBias: peg.leftBias.toFixed(6) })));
  return sha256Hex(JSON.stringify(norm));
}

export function computeRound(combinedSeedHex: string, dropColumn: number) {
  const seed = seedFromHexBE(combinedSeedHex);
  const prng = new XorShift32(seed);
  const pegMap = buildPegMap(prng);
  const pegMapHash = pegMapHashOf(pegMap);
  let pos = 0;
  const path: ('L'|'R')[] = [];
  const adj = (dropColumn - Math.floor(R/2)) * 0.01;
  for (let r = 0; r < R; r++) {
    const pegIndex = Math.min(pos, r);
    const peg = pegMap[r][pegIndex];
    let bias = peg.leftBias + adj;
    if (bias < 0) bias = 0;
    if (bias > 1) bias = 1;
    const rnd = prng.rand();
    if (rnd < bias) {
      path.push('L');
    } else {
      path.push('R');
      pos += 1;
    }
  }
  const binIndex = pos;
  return { pegMap, pegMapHash, path, binIndex };
}
