'use client';
import React, { useEffect, useRef, useState } from 'react';
import { computeRound } from '../../lib/engine.client';
import Matter from 'matter-js';

export default function GamePage() {
  const canvasRef = useRef<HTMLDivElement | null>(null);
  const [dropColumn, setDropColumn] = useState(6);
  const [clientSeed, setClientSeed] = useState('user-seed');
  const [serverSeed, setServerSeed] = useState('');
  const [nonce, setNonce] = useState('');
  const [running, setRunning] = useState(false);
  const engineRef = useRef<Matter.Engine | null>(null);

  useEffect(() => {
    return () => {
      if (engineRef.current) {
        Matter.Engine.clear(engineRef.current);
      }
    };
  }, []);

  async function createRound() {
    // get commit (demo returns serverSeed too)
    const commitRes = await fetch('/api/rounds/commit', { method: 'POST' }).then(r => r.json());
    setServerSeed(commitRes.serverSeed);
    setNonce(commitRes.nonce);
    // start
    const startRes = await fetch('/api/rounds/start', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ roundId: commitRes.roundId, serverSeed: commitRes.serverSeed, nonce: commitRes.nonce, clientSeed, dropColumn, betCents:100 })
    }).then(r=>r.json());
    // compute round locally for deterministic path
    const result = computeRound(startRes.combinedSeed, dropColumn);
    // simple Matter.js visual: we will render pegs and drop ball that follows physics (not authoritative)
    renderMatter(result);
  }

  function renderMatter(result: any) {
    if (!canvasRef.current) return;
    setRunning(true);
    const width = 480, height = 600;
    const engine = Matter.Engine.create();
    engineRef.current = engine;
    const render = Matter.Render.create({
      element: canvasRef.current,
      engine,
      options: { width, height, wireframes: false, background: '#0f172a' }
    });
    // create boundaries
    const ground = Matter.Bodies.rectangle(width/2, height+20, width, 40, { isStatic: true });
    const left = Matter.Bodies.rectangle(-20, height/2, 40, height, { isStatic: true });
    const right = Matter.Bodies.rectangle(width+20, height/2, 40, height, { isStatic: true });
    Matter.World.add(engine.world, [ground,left,right]);

    // draw pegs
    const pegRadius = 6;
    const startX = width/2;
    const startY = 80;
    const xSpacing = 40;
    const ySpacing = 40;
    for (let r=0;r<12;r++){
      const count = r+1;
      const rowY = startY + r*ySpacing;
      const rowWidth = (count-1)*xSpacing;
      for (let i=0;i<count;i++){
        const x = startX - rowWidth/2 + i*xSpacing;
        const peg = Matter.Bodies.circle(x, rowY, pegRadius, { isStatic: true, render:{fillStyle:'#94a3b8'}});
        Matter.World.add(engine.world, peg);
      }
    }

    // drop ball at column position mapped to x
    const colX = startX - 12*xSpacing/2 + dropColumn*xSpacing;
    const ball = Matter.Bodies.circle(colX, 20, 10, { restitution: 0.3, friction: 0.05, render:{fillStyle:'#f97316'}});
    Matter.World.add(engine.world, ball);

    Matter.Engine.run(engine);
    Matter.Render.run(render);

    // stop after 6 seconds
    setTimeout(()=> {
      Matter.Render.stop(render);
      Matter.World.clear(engine.world, false);
      Matter.Engine.clear(engine);
      render.canvas.remove();
      setRunning(false);
    }, 6000);
  }

  return (
    <main style={{padding:20}}>
      <h2>Plinko — Game (Demo)</h2>
      <div style={{display:'flex',gap:20}}>
        <div>
          <label>Client Seed: <input value={clientSeed} onChange={e=>setClientSeed(e.target.value)} /></label><br/>
          <label>Drop Column (0-12): <input type="number" value={dropColumn} onChange={e=>setDropColumn(Number(e.target.value))} min={0} max={12} /></label><br/>
          <button onClick={createRound} disabled={running}>Create & Drop</button>
          <div style={{marginTop:10}}>ServerSeed: <code style={{display:'block',maxWidth:480,overflow:'auto'}}>{serverSeed}</code></div>
          <div>Nonce: {nonce}</div>
        </div>
        <div ref={canvasRef} />
      </div>
    </main>
  );
}
