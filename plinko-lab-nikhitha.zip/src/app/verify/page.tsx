'use client';
import React, {useState} from 'react';

export default function VerifyPage(){
  const [serverSeed,setServerSeed] = useState('');
  const [clientSeed,setClientSeed] = useState('');
  const [nonce,setNonce] = useState('');
  const [dropColumn,setDropColumn] = useState(6);
  const [result,setResult] = useState<any>(null);

  async function onVerify(e:any){
    e.preventDefault();
    const res = await fetch('/api/verify', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({serverSeed, clientSeed, nonce, dropColumn})});
    const j = await res.json();
    setResult(j);
  }

  return (
    <main style={{padding:20}}>
      <h2>Verifier</h2>
      <form onSubmit={onVerify}>
        <div><label>Server Seed: <input value={serverSeed} onChange={e=>setServerSeed(e.target.value)} style={{width:600}} /></label></div>
        <div><label>Client Seed: <input value={clientSeed} onChange={e=>setClientSeed(e.target.value)} /></label></div>
        <div><label>Nonce: <input value={nonce} onChange={e=>setNonce(e.target.value)} /></label></div>
        <div><label>Drop Column: <input type="number" value={dropColumn} onChange={e=>setDropColumn(Number(e.target.value))} min={0} max={12} /></label></div>
        <button type="submit">Verify</button>
      </form>
      {result && <div style={{marginTop:20}}>
        <pre>{JSON.stringify(result,null,2)}</pre>
      </div>}
    </main>
  );
}
