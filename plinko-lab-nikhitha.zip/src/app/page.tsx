'use client';
import React, { useEffect, useRef, useState } from 'react';
import dynamic from 'next/dynamic';
import Link from 'next/link';

export default function Page() {
  return (
    <main style={{padding:20,fontFamily:'Inter, sans-serif'}}>
      <h1>Plinko Lab — plinko-lab-nikhitha</h1>
      <p>Provably-fair Plinko demo. Use the controls to create a round and drop the ball.</p>
      <div style={{display:'flex',gap:20}}>
        <div style={{flex:1, minWidth:320}}>
          <Link href="/game"><button>Open Game</button></Link>
          <Link href="/verify"><button style={{marginLeft:10}}>Verifier</button></Link>
        </div>
      </div>
    </main>
  );
}
