import { NextApiRequest, NextApiResponse } from 'next';
import { sha256Hex } from '../lib/hash';
import { computeRound } from '../lib/engine';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  const params = req.method === 'GET' ? req.query : req.body;
  const { serverSeed, clientSeed, nonce, dropColumn } = params as any;
  if (!serverSeed || clientSeed === undefined || nonce === undefined || dropColumn === undefined) {
    return res.status(400).json({ error: 'missing params' });
  }
  const commitHex = sha256Hex(`${serverSeed}:${nonce}`);
  const combinedSeed = sha256Hex(`${serverSeed}:${clientSeed}:${nonce}`);
  const { pegMapHash, binIndex } = computeRound(combinedSeed, Number(dropColumn));
  return res.json({ commitHex, combinedSeed, pegMapHash, binIndex });
}
