import { NextApiRequest, NextApiResponse } from 'next';
import crypto from 'crypto';
import { sha256Hex } from '../../../lib/hash';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end();
  const serverSeed = crypto.randomBytes(32).toString('hex');
  const nonce = (Math.floor(Math.random()*1e9)).toString();
  const commitHex = sha256Hex(`${serverSeed}:${nonce}`);
  // NOTE: In this demo we return serverSeed for local use; in production serverSeed is stored server-side and not returned.
  return res.json({ roundId: crypto.randomBytes(12).toString('hex'), commitHex, nonce, serverSeed });
}
