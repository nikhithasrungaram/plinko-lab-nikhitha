import { NextApiRequest, NextApiResponse } from 'next';
import { sha256Hex } from '../../../lib/hash';
import { computeRound } from '../../../lib/engine';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end();
  const { roundId, serverSeed, nonce, clientSeed, dropColumn, betCents } = req.body;
  if (!serverSeed || !nonce || clientSeed === undefined) {
    return res.status(400).json({ error: 'missing parameters for demo start' });
  }
  const commitCheck = sha256Hex(`${serverSeed}:${nonce}`);
  // combinedSeed
  const combinedSeed = sha256Hex(`${serverSeed}:${clientSeed}:${nonce}`);
  const result = computeRound(combinedSeed, Number(dropColumn));
  // In real app, persist round without revealing serverSeed.
  return res.json({
    roundId,
    pegMapHash: result.pegMapHash,
    rows: 12,
    binIndex: result.binIndex,
    path: result.path,
    combinedSeed
  });
}
