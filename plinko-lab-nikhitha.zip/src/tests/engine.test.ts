import { sha256Hex } from '../lib/hash';
import { computeRound } from '../lib/engine';

test('test vector from spec', () => {
  const serverSeed = "b2a5f3f32a4d9c6ee7a8c1d33456677890abcdeffedcba0987654321ffeeddcc";
  const nonce = "42";
  const clientSeed = "candidate-hello";

  const commitHex = sha256Hex(`${serverSeed}:${nonce}`);
  expect(commitHex).toBe('bb9acdc67f3f18f3345236a01f0e5072596657a9005c7d8a22cff061451a6b34');

  const combinedSeed = sha256Hex(`${serverSeed}:${clientSeed}:${nonce}`);
  expect(combinedSeed).toBe('e1dddf77de27d395ea2be2ed49aa2a59bd6bf12ee8d350c16c008abd406c07e0');

  const result = computeRound(combinedSeed, 6);
  expect(result.binIndex).toBe(6);

  const b0 = result.pegMap[0][0].leftBias.toFixed(6);
  const b10 = result.pegMap[1][0].leftBias.toFixed(6);
  const b11 = result.pegMap[1][1].leftBias.toFixed(6);
  const b20 = result.pegMap[2][0].leftBias.toFixed(6);
  expect(b0).toBe('0.422123');
  expect(b10).toBe('0.552503');
  expect(b11).toBe('0.408786');
  expect(b20).toBe('0.491574');
});
